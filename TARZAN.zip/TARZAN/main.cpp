#include <iostream>
#include <stdlib.h>
#include <string>
#include <GL/gl.h>
#include <GL/glut.h>
#include <sstream>
#include <unistd.h>

using namespace std;

int score = 0;
float posx = 0;
float sunx = 0;
float cloudx = 0;
float cldx = 0;
float cldx1 = 0;
float suny =0;
int life = 0;

//TARZAN
void tarzan()
{
    glMatrixMode(GL_MODELVIEW);

glPushMatrix();

    glTranslatef( posx,-.4,0);

    glPushMatrix();
        //BODY
        glPushMatrix();
           glColor3ub(200,167,117);
           glTranslatef(0,-.18,0);
           glScalef(0.5,1.25,0);
           glutSolidCube(.2);
        glPopMatrix();
        //HEAD
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(0,0,0);
           glScalef(0.45,1,0);
           glutSolidSphere(.075,20,20);
        glPopMatrix();
        //HAIR
        glPushMatrix();
           glColor3ub(97,70,51);
           glTranslatef(-0.005,0.055,0);
           glScalef(0.5,0.25,0);
           glutSolidSphere(.075,20,20);
        glPopMatrix();

        glPushMatrix();
           glColor3ub(97,70,51);
           glTranslatef(0.025,0.01,0);
           glScalef(0.2,1,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(0.02,0.005,0);
           glScalef(0.15,0.8,0);
           glutSolidSphere(.03,20,20);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(97,70,51);
           glTranslatef(0.03,-0.04,0);
           glScalef(0.15,0.15,0);
           glutSolidSphere(.075,20,20);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(97,70,51);
           glTranslatef(0.025,0.07,0);
           glScalef(0.25,0.25,0);
           glutSolidSphere(.075,20,20);
        glPopMatrix();
        //EYE
          glPushMatrix();
            glColor3f(1,1,1);
            glTranslatef(-.017,-.007,.0);
            glScalef(.4,1,0);
            glutSolidSphere(.013,20,20);
          glPopMatrix();
          glPushMatrix();
            glTranslatef(-.0175,-.001,.0);
            glColor3ub(97,70,51);
            glScalef(0.33,0.75,0);
            glutSolidCube(.02);
        glPopMatrix();
        glPushMatrix();
            glColor3ub(97,70,51);
            glTranslatef(-.012,.015,0);
            glRotatef(230,1,0.5,0);
            glScalef(.5,1.5,0);
            glutSolidCube(.02);
        glPopMatrix();
        glPushMatrix();
            glColor3ub(0,0,0);
            glTranslatef(-.013,-.044,0);
            glScalef(.58,0.8,0);
            glutSolidSphere(.013,20,20);
        glPopMatrix();
        glPushMatrix();
            glColor3ub(0,0,0);
            glTranslatef(-.01,-.042,0);
            glScalef(.58,0.8,0);
            glutSolidSphere(.013,20,20);
        glPopMatrix();
         glPushMatrix();
            glColor3ub(255,36,44);
            glTranslatef(-.013,-.047,0);
            glScalef(.55,0.8,0);
            glutSolidSphere(.008,20,20);
        glPopMatrix();
        glPushMatrix();
            glColor3ub(255,36,44);
            glTranslatef(-.01,-.046,0);
            glScalef(.55,0.8,0);
            glutSolidSphere(.008,20,20);
        glPopMatrix();
        //hand
        glPushMatrix();
           glColor3ub(196,153,111);
           glTranslatef(-.06,-.15,0);
           glScalef(0.2,1.5,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(-.06,-.23,0);
           glScalef(0.24,0.3,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(196,153,111);
           glTranslatef(.06,-.15,0);
           glScalef(0.2,1.5,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(.06,-.23,0);
           glScalef(0.24,0.3,0);
           glutSolidCube(.1);
        glPopMatrix();
        //LEG
        glPushMatrix();
           glColor3ub(200,167,117);
           glTranslatef(0,-.3,0);
           glScalef(0.25,1,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(200,167,117);
           glTranslatef(-.03,-.3,0);
           glScalef(0.37,4,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(200,167,117);
           glTranslatef(.03,-.3,0);
           glScalef(0.37,4,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(.03,-.5,0);
           glScalef(0.4,0.3,0);
           glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
           glColor3ub(216,167,111);
           glTranslatef(-.03,-.5,0);
           glScalef(0.4,0.3,0);
           glutSolidCube(.1);
        glPopMatrix();
    glPopMatrix();
    //pant
    glPushMatrix();
           glColor3ub(112,86,69);
           glTranslatef(0,-.32,0);
           glScalef(1,1.35,0);
           glutSolidCube(.1);
        glPopMatrix();


glPopMatrix();
}
// PAHAR PORBOT
void hill()
{
    glColor3ub(147,219,208);
    glPushMatrix();
        glTranslatef(-.95,.050,0);
        glutSolidCone(.5,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.55,.050,0);
        glutSolidCone(.45,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.15,.050,0);
        glutSolidCone(.5,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.15,.050,0);
        glutSolidCone(.4,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.55,.050,0);
        glutSolidCone(.5,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.95,.050,0);
        glutSolidCone(.4,.5,5,5);
    glPopMatrix();

}
void hill2()
{
  glColor3ub(160,217,146);

    glPushMatrix();
        glTranslatef(.2,.050,0);
        glutSolidCone(.51,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.55,.050,0);
        glutSolidCone(.35,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.8,.050,0);
        glutSolidCone(.4,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.35,.050,0);
        glutSolidCone(.45,.5,5,5);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.80,.050,0);
        glutSolidCone(.51,0.5,5,5);
    glPopMatrix();

}

void tila()
{
    glColor3ub(147,207,143);

    glPushMatrix();
        glTranslatef(.1,.030,0);
        glutSolidCone(.4,.5,4,1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.8,.030,0);
        glutSolidCone(.27,.5,4,1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.4,.030,0);
        glutSolidCone(.32,.5,4,1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(.9,.030,0);
        glutSolidCone(.32,.5,4,1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.45,.010,0);
        glutSolidCone(.37,.5,4,1);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(-.95,.080,0);
        glutSolidCone(.30,.5,4,1);
    glPopMatrix();

}
// JANGLE
void jangle()
{
    float j1=0.10;
    glPushMatrix();

    glColor3ub(144,200,117);
    glPushMatrix();
        glTranslatef(-1,0.05,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
    glPushMatrix();
        glTranslatef(-.90,0,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+j1,0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(2*j1),0.05,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(3*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(4*j1),0.0,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(5*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(6*j1),0.035,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(7*j1),0.065,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(8*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(9*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(10*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(11*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(12*j1),0.0,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(13*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(14*j1),0.05,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(15*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(16*j1),0.060,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(17*j1),0.05,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(18*j1),0.025,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(19*j1),0.0,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPopMatrix();
}
//Jangle2
void jangle2()
{
    glPushMatrix();

    glColor3ub(179,230,84);
   glPushMatrix();
        glTranslatef(.8,-.85,0);
        glScalef(7,5,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
    glColor3ub(90,155,87);
    glPushMatrix();
        glTranslatef(-0.7,-0.25,0);
        glScalef(6,2,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPopMatrix();

}
//BASEPOINT
void basepoint()
{

    float j1=0.10;
    glPushMatrix();

    glColor3ub(136,162,11);
    glPushMatrix();
        glTranslatef(-1,-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
    glPushMatrix();
        glTranslatef(-.90,-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+j1,-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(2*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(3*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(4*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(5*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(6*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(7*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(8*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(9*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(10*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(11*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(12*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(13*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(14*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(15*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(16*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(17*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(18*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(19*j1),-0.34,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();


   glColor3ub(175,191,20);
    glPushMatrix();
        glTranslatef(-1,-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
    glPushMatrix();
        glTranslatef(-.90,-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+j1,-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(2*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(3*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(4*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(5*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(6*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(7*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(8*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(9*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(10*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(11*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(12*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(13*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(14*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(15*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(16*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(17*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(18*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
   glPushMatrix();
        glTranslatef(-.90+(19*j1),-0.38,0);
        glScalef(0.5,1,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();

   glPushMatrix();
        glTranslatef(0,-.7,0);
        glScalef(30,2,0);
        glutSolidCube(.3);
    glPopMatrix();

}

//TREE

void Tree()
{

    for(int i=0;i<=5;i++)
    {
        float x=0.48;
     glPushMatrix();
        //tree body
        glPushMatrix();
                glColor3ub(154, 148, 6);
                glTranslatef(-.91+(i*x),-.25,0);
                glScalef(.075,1,0);
                glutSolidCube (0.3);
        glPopMatrix();
        glPushMatrix();
                glColor3ub(146, 118, 16);
                glTranslatef(-.9+(i*x),-.25,0);
                glScalef(.075,1,0);
                glutSolidCube (0.3);
        glPopMatrix();
        //tree leafe
        glColor3ub(140,176,22);
        glPushMatrix();
            glTranslatef(-.86+(i*x),-.069,0);
            glScalef(0.3,0.7,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
        glColor3ub(80,151,9);
       glPushMatrix();
            glTranslatef(-.86+(i*x),-.069,0);
            glScalef(0.25,0.5,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(140,176,22);
       glPushMatrix();
            glTranslatef(-.955+(i*x),-.069,0);
            glScalef(0.3,0.7,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(80,151,9);
       glPushMatrix();
            glTranslatef(-.955+(i*x),-.069,0);
            glScalef(0.25,0.5,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(140,176,22);
       glPushMatrix();
            glTranslatef(-.9+(i*x),.07,0);
            glScalef(0.4,0.65,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(80,151,9);
       glPushMatrix();
            glTranslatef(-.9+(i*x),.07,0);
            glScalef(0.35,0.6,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glPushMatrix();
            glTranslatef(-.9+(i*x),-.06,0);
            glScalef(0.35,0.6,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       //tree root
       glColor3ub(140,176,22);
        glPushMatrix();
            glTranslatef(-.87+(i*x),-.37,0);
            glScalef(0.2,0.35,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(80,151,9);
       glPushMatrix();
            glTranslatef(-.87+(i*x),-.37,0);
            glScalef(0.15,0.25,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(140,176,22);
       glPushMatrix();
            glTranslatef(-.935+(i*x),-.37,0);
            glScalef(0.2,0.35,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
       glColor3ub(80,151,9);
       glPushMatrix();
            glTranslatef(-.935+(i*x),-.37,0);
            glScalef(0.15,0.25,0);
            glutSolidSphere (0.2, 40, 30);
       glPopMatrix();
   glPopMatrix();
   }

}
//ROAD
void road()
{
 for(int i=0 ; i<=19 ;i++){
  float x = 0.10;
   glColor3ub(247,167,60);
   glPushMatrix();
        glTranslatef(-.9+(i*x),-.90,0);
        glScalef(2,2,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
 }
 for(int i=0 ;i<=19 ; i++)
 {
     float x = 0.10;
      glColor3ub(225,178,64);
   glPushMatrix();
        glTranslatef(-.9+(i*x),-.97,0);
        glScalef(2,2,0);
        glutSolidSphere (0.2, 40, 30);
   glPopMatrix();
 }
}
//sky
void sky()
{
    glPushMatrix();
        glTranslatef(0,.8,0);
        glScalef(30,7,5);
        glColor3f(0.70, 0.96, 0.96);
        glutSolidCube(.2);
    glPopMatrix();

}
//sun
void sun()
{
    sunx+=0.00012;
    suny+=0.00012;
    if(sunx>=1)
    {
        sunx = -1;
    }
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(sunx,suny,0);
    glPushMatrix();
        glColor3f(2.0, 1.5, 0.6);
        glTranslatef(.055,0.67,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.14,20,20);
    glPopMatrix();

    glPushMatrix();
        glColor3f(1.0, 0.8, 0.0);
        glTranslatef(.055,0.67,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.11,20,20);
    glPopMatrix();
glPopMatrix();

}
//cloud
void cloud  ()
{
    cloudx+=0.0022;
    if(cloudx>=1)
    {
        cloudx = -1.5;
    }
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(cloudx,0,0);
    glPushMatrix();
        glColor3f(0.94, 1.0, 0.94);
        glTranslatef(.1,0.55,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.15,20,20);
        glTranslatef(-.095,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.13,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.05,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.09,0,0);
        glutSolidSphere(.05,20,20);
    glPopMatrix();
    glPushMatrix();
        glColor3f(0.94, 1.0, 0.94);
        glTranslatef(.01,0.55,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.15,20,20);
        glTranslatef(-.095,0,0);
        glutSolidSphere(.1,20,20);
    glPopMatrix();
glPopMatrix();

}
//cloud small
void cloudsmall  ()
{
      cldx+=0.0025;
    if(cldx>=2)
    {
        cldx = -.8;
    }
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(cldx,0,0);
    glPushMatrix();
        glColor3f(0.94, 1.0, 0.94);
        glTranslatef(-.75,0.8,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.15,20,20);
        glTranslatef(-.095,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.13,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.05,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.09,0,0);
        glutSolidSphere(.05,20,20);
    glPopMatrix();
glPopMatrix();

  cldx1+=0.002;
    if(cldx1>=0.4)
    {
        cldx1 = -2;
    }
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(cldx1,0,0);
    glPushMatrix();
        glColor3f(0.94, 1.0, 0.94);
        glTranslatef(.70,0.65,0);
        glScalef(0.65,1,0);
        glutSolidSphere(.15,20,20);
        glTranslatef(-.095,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.13,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.05,0,0);
        glutSolidSphere(.1,20,20);
        glTranslatef(.09,0,0);
        glutSolidSphere(.05,20,20);
    glPopMatrix();
glPopMatrix();

}



//FOR CONTINUOSE ELEMENT

static float EE1 = .0001;


void Update_EElement_1(int value) {
	EE1 -= .00099 ;
	if (EE1 < -3) {
		EE1 += 3;
	}

	glutPostRedisplay();//current window redisplay

	glutTimerFunc(.1, Update_EElement_1, 1);//callback triggar

}
float EE2 = .0001;


void Update_EElement_2(int value) {
	EE2 -= .00035 ;
	if (EE2 < -3.0) {
		EE2 += 3.0;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_EElement_2, 1);

}
float EE3 = .0001;


void Update_EElement_3(int value) {
	EE3 -= .00035 ;
	if (EE3 < -3.2) {
		EE3 += 3.2;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_EElement_3, 1);

}
float EE4 = .0001;


void Update_EElement_4(int value) {
	EE4 -= .00099 ;
	if (EE4 < -3) {
		EE4 += 3;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_EElement_4, 1);

}



float EE5 = .0001;


void Update_EElement_5(int value) {
	EE5 -= .00095 ;
	if (EE5 < -3) {
		EE5 += 3;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_EElement_5, 1);

}

//SHOW TEXT IN SCREEN
void DrawText(const char *text, int length, int x, int y)
{
    glMatrixMode(GL_PROJECTION);
    double *matrix = new double[100];
    glGetDoublev(GL_PROJECTION_MATRIX, matrix);//return the value
    glLoadIdentity();
    gluOrtho2D(0.0, 600.0, 0.0, 400.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glPushMatrix();
        glLoadIdentity();
        glRasterPos2i(x, y);// specify the arallel scanning position for pixel operations

        for(int i=0; i<length; i++)
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (int)text[i]);//Character to render

    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glLoadMatrixd(matrix);
    glMatrixMode(GL_MODELVIEW);
}
//GAME OVER
void Over ()
{

    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
        glPushMatrix();
            glTranslatef(0,.8,0);
            glScalef(30,70,5);
            glColor3f(0.70, 0.96, 0.96);
            glutSolidCube(.4);
        glPopMatrix();
        sun();
        cloud();
        cloudsmall();
        for(int i=0 ; i<=19 ;i++){
        float x = 0.10;
        glColor3ub(59,118,41);
        glPushMatrix();
            glTranslatef(-.9+(i*x),-.90,0);
            glScalef(2,2,0);
            glutSolidSphere (0.2, 40, 30);
        glPopMatrix();
        }

        glPushMatrix();

            glPushMatrix();
            glColor3f(.65,.32,.0);
            glTranslatef(0.012,.015,0);
            glScalef(5,8,1);
            glutSolidCube(.1);
            glPopMatrix();
            glPushMatrix();
            glColor3f(.5,.2,.0);
            glTranslatef(0,.045,0);
            glScalef(5,8,1);
            glutSolidCube(.1);
            glPopMatrix();
            glColor3f(0,.3,.2);

            glColor3f(0.70, 0.96, 0.96);
            string text;

            text = "Your Score is:";
            DrawText(text.data(), text.size(), 260, 190);
            stringstream conv;
            conv << score << endl;
            string  Score_s = conv.str();
            DrawText(Score_s.data(), Score_s.size(), 330, 190);
            glColor3f(1,0.5,0);
            text = "GAME OVER";
            DrawText(text.data(), text.size(), 260, 220);


        glPopMatrix();



    glPopMatrix();

     glFlush ();
}
//level Up element
void EElement ()
{

glMatrixMode(GL_MODELVIEW);

glPushMatrix();
    glTranslatef(-.2,0,0);
    glPushMatrix();


            //TREE BRANCH
        glPushMatrix();
        glTranslatef(0,EE1 +1.2 ,0);

            glPushMatrix();


            if( EE1 <= -1.5 && posx <= -.7 )
            {
                EE1 -= .5;
                life = life+1;
                cout << life << endl;
                //glutDisplayFunc(Over);

            }
            else
            {
                //BRANCHES OF A TREE
                glTranslatef(-.6,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_EElement_1, .0001);

            }

            glPopMatrix();

        glPopMatrix();



    //Apple

        glPushMatrix();
        glTranslatef(0,EE2 +1.7 ,0);
            glPushMatrix();

            if( EE2 <= -2.2 && posx <= 0 && posx >-.4 )
            {
                EE2 -= .5;
                score = score + 5;
                glutTimerFunc(.2, Update_EElement_2, .0001);

            }
            else
            {
                glTranslatef(0,0,0);
                glColor3ub(255,52,38);
                glScalef(.2,.4,0);
                glutSolidSphere(.2,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(90,88,52);
                glScalef(.4,.2,0);
                glutSolidSphere(.1,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(90,88,52);
                glScalef(.2,1,0);
                glutSolidCube(.5);
                glTranslatef(.80,.15,0);
                glColor3ub(66,122,45);
                glScalef(2,0.5,0);
                glutSolidSphere(.5,20,20);
                glTranslatef(-.60,-1.5,0);
                glColor3ub(255,103,73);
                glScalef(.6,.7,0);
                glutSolidSphere(.5,20,20);

                glutTimerFunc(.2, Update_EElement_2, .0001);
            }

            glPopMatrix();
        glPopMatrix();


    //ORANGE
        glPushMatrix();
        glTranslatef(0,EE3+2,0);
            glPushMatrix();

           if( EE3 <= -2.4 && posx >= .05)
            {
                EE3 -= .5;


                glutTimerFunc(.2, Update_EElement_3, .0001);
                score = score + 5;
                cout << score << endl;
            }
            else
            {

                glTranslatef(.5,0,0);
                glColor3ub(102,76,161);
                glScalef(.2,.35,0);
                glutSolidSphere(.2,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(135,96,57);
                glScalef(.4,.2,0);
                glutSolidSphere(.1,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(135,96,57);
                glScalef(.2,1,0);
                glutSolidCube(.5);
                glTranslatef(.80,.15,0);
                glColor3ub(66,122,45);
                glScalef(2,0.5,0);
                glutSolidSphere(.5,20,20);
                glTranslatef(-.60,-1.5,0);
                glColor3ub(196,132,246);
                glScalef(.6,.6,0);
                glutSolidSphere(.5,20,20);
                 glutTimerFunc(.2, Update_EElement_3, .0001);
            }

                glPopMatrix();


            glPopMatrix();

        //BRANCH
        glPushMatrix();
            glTranslatef(0,EE4 +1.2 ,0);


            glPushMatrix();


            if( EE4 <= -1.5 && posx >= .7 )
            {
                EE4 -= .5;
                life = life +1;
                cout << life << endl;
                //glutDisplayFunc(Over);

            }
            else
            {
                glTranslatef(1,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_EElement_4, .0001);
            }

        glPopMatrix();

    glPopMatrix();


            //BRANCH
        glPushMatrix();
            glTranslatef(0,EE5 +2 ,0);

            glPushMatrix();


            if( EE5 <= -2.3 && posx <=.1 && posx >= -.2 )

                {
                EE5 -= .5;
                life = life+1;
                cout << life << endl;
                //glutDisplayFunc(Over);


            }
            else
            {
                glTranslatef(.1,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_EElement_5, .0001);
            }

        glPopMatrix();

    glPopMatrix();



    glPopMatrix();
    glFlush();

glPopMatrix();

}

static float E1 = .0001;

void Update_Element_1(int value) {
	E1 -= .000029 ;
	if (E1 < -3) {
		E1 += 3;
	}

	glutPostRedisplay();

	glutTimerFunc(.1, Update_Element_1, 1);

}
float E2 = .0001;

void Update_Element_2(int value) {
	E2 -= .000015 ;
	if (E2 < -3.0) {
		E2 += 3.0;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_Element_2, 1);

}
float E3 = .0001;

void Update_Element_3(int value) {
	E3 -= .000025 ;
	if (E3 < -3.2) {
		E3 += 3.2;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_Element_3, 1);

}
float E4 = .0001;

void Update_Element_4(int value) {
	E4 -= .000029 ;
	if (E4 < -3) {
		E4 += 3;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_Element_4, 1);

}

float E5 = .0001;

void Update_Element_5(int value) {
	E5 -= .000055 ;
	if (E5 < -3) {
		E5 += 3;
	}

	glutPostRedisplay();
	glutTimerFunc(.1, Update_Element_5, 1);

}
//ELEMENT
void Element ()
{

glMatrixMode(GL_MODELVIEW);

glPushMatrix();
    glTranslatef(-.2,0,0);
    glPushMatrix();


        //Tree BRanch
        glPushMatrix();
        glTranslatef(0,E1 +1.2 ,0);

            glPushMatrix();


            if( E1 <= -1.5 && posx <= -.7 )
            {
               glColor3f(1,0.7,0);
               E1 -= .5;
               life = life+1;
               //glutDisplayFunc(Over);
               cout << life << endl;
            }
            else
            {
                glTranslatef(-.6,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_Element_1, .0001);

            }

            glPopMatrix();

        glPopMatrix();



    // water melon

        glPushMatrix();
        glTranslatef(0,E2 +1.7 ,0);
            glPushMatrix();

            if( E2 <= -2.1 && posx <= 0 && posx >-.2 )
            {
                E2 -= .5;
                score = score + 5;
                glutTimerFunc(.2, Update_Element_2, .0001);

            }
            else
            {
                glTranslatef(0,0,0);
                glScalef(.7,.7,0);
                glColor3ub(255,92,100);
                glutSolidCone(.1,.8,3,3);
                glTranslatef(0,-.058,0);
                glColor3ub(244,243,178);
                glScalef(.7,.2,0);
                glutSolidSphere(.13,20,20);
                glTranslatef(0,-.06,0);
                glColor3ub(58,104,94);
                glScalef(.7,.4,0);
                glutSolidSphere(.2,20,20);
                glutTimerFunc(.2, Update_Element_2, .0001);
            }

            glPopMatrix();
        glPopMatrix();


    //  ORANGE
        glPushMatrix();
        glTranslatef(0,E3+2,0);
            glPushMatrix();

            if( E3 <= -2.4 && posx >= .05)
            {
                E3 -= .5;


                glutTimerFunc(.2, Update_Element_3, .0001);
                score = score + 5;
                cout << score << endl;
            }
            else
            {
                glTranslatef(.5,0,0);
                glColor3ub(253,156,1);
                glScalef(.2,.35,0);
                glutSolidSphere(.2,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(90,88,52);
                glScalef(.4,.2,0);
                glutSolidSphere(.1,20,20);
                glTranslatef(0,.15,0);
                glColor3ub(90,88,52);
                glScalef(.2,1,0);
                glutSolidCube(.5);
                glTranslatef(.80,.15,0);
                glColor3ub(66,122,45);
                glScalef(2,0.5,0);
                glutSolidSphere(.5,20,20);
                glTranslatef(-.60,-1.5,0);
                glColor3ub(254,188,142);
                glScalef(.6,.6,0);
                glutSolidSphere(.5,20,20);
                 glutTimerFunc(.2, Update_Element_3, .0001);
            }

                glPopMatrix();


            glPopMatrix();

        //Branch
        glPushMatrix();
            glTranslatef(0,E4 +1.2 ,0);


            glPushMatrix();


            if( E4 <= -1.5 && posx >= .7 )
            {
                E4 -= .5;
                life = life+1;
                cout << life << endl;
                //glutDisplayFunc(Over);


            }
            else
            {
                glTranslatef(1,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_Element_4, .0001);
            }

        glPopMatrix();

    glPopMatrix();


            //branch
        glPushMatrix();
            glTranslatef(0,E5 +2 ,0);

            glPushMatrix();


            if( E5 <= -2.3 && posx <=.1 && posx >= -.2 )

                {
                E5 -= .5;
                life = life+1;
                cout << life << endl;
                //glutDisplayFunc(Over);

            }
            else
            {
                glTranslatef(.1,0,0);
                glColor3ub(229, 182, 151);
                glRotatef(-60,.2,.7,0);
                glScalef(1,0.5,0);
                glutSolidCube (0.2);
                glColor3ub(60, 174, 80);
                glTranslatef(.1,.1,0);
                glScalef(0.25,0.5,0);
                glutSolidSphere (0.3, 40, 30);
                glTranslatef(.1,-.4,0);
                glScalef(0.45,0.7,0);
                glutSolidSphere (0.5, 40, 30);
                glTranslatef(.7,.1,0);
                glScalef(1.5,1,0);
                glutSolidSphere (0.5, 40, 30);

                glutTimerFunc(.2, Update_Element_5, .0001);
            }

        glPopMatrix();

    glPopMatrix();



    glPopMatrix();
    glFlush();

glPopMatrix();

}

//BACKGROUND FOR THE GAME
void Background()
{
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        sky();
        sun();
        cloud ();
        cloudsmall();
        hill();
        hill2();
        tila();
        jangle();
        jangle2();
        basepoint();
        Tree();
        road();
        tarzan();

        if(life <=3)
        {
            glColor3f(1,0.7,0);
            string text = "Only 3 Chances:";
            DrawText(text.data(), text.size(), 100, 380);
            stringstream conv;
            conv << life << endl;
            string  life_s = conv.str();
            DrawText(life_s.data(), life_s.size(), 185, 380);
            if (score >= 50)
            {
                glPushMatrix() ;
                    glColor3f(1,0.7,0);
                    string text = "LEVEL INCREASED";
                    DrawText(text.data(), text.size(), 260, 365);
                    glPopMatrix();
                glPushMatrix();
                    EElement ();
                glPopMatrix();

            }
            else
            {
                glPushMatrix();
                Element ();
                glPopMatrix();
            }
        }
        else
        {
            glPushMatrix();
                glutDisplayFunc(Over);
            glPopMatrix();
        }
    glPushMatrix();
        glColor3f(1,0.7,0);
        string text = "SCORE:";
        DrawText(text.data(), text.size(), 500, 380);
        stringstream convert;
        convert << score << endl;
        string  score_s = convert.str();
        DrawText(score_s.data(), score_s.size(),550, 380);
    glPopMatrix();
   glFlush ();
}

//MENU SCREEN
void Menu()
{
    glPushMatrix();

        glPushMatrix();
            glTranslatef(0,.8,0);
            glScalef(30,70,5);
            glColor3f(0.70, 0.96, 0.96);
            glutSolidCube(.4);
        glPopMatrix();
        sun();
        cloud();
        cloudsmall();
        for(int i=0 ; i<=19 ;i++){
        float x = 0.10;
        glColor3ub(59,118,41);
        glPushMatrix();
            glTranslatef(-.9+(i*x),-.90,0);
            glScalef(2,2,0);
            glutSolidSphere (0.2, 40, 30);
        glPopMatrix();
        }
        glPushMatrix();
            glColor3f(.65,.3,.0);
            glTranslatef(.012,-.12,0);
            glScalef(5,10,1);
        glutSolidCube(.1);
        glPopMatrix();
        glPushMatrix();
            glColor3f(.5,.2,.0);
            glTranslatef(0,-.1,0);
            glScalef(5,10,1);
        glutSolidCube(.1);
        glPopMatrix();

        glPushMatrix();
            glColor3f(.9,.8,.0);
            glTranslatef(0,.28,0);
            glScalef(3,.7,1);
        glutSolidCube(.2);
        glPopMatrix();

        glColor3f(0,.3,.2);
        glPushMatrix();
            glTranslatef(0,-.03,0);
            glScalef(2,.8,1);
            glutSolidCube(.2);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0,-0.3,0);
            glScalef(2,.8,1);
            glutSolidCube(.2);
        glPopMatrix();



    glPopMatrix();


    string text;
    glColor3f(0.6,0.5,0);
    text = "JUNGLE TARZAN";
    DrawText(text.data(), text.size(), 251, 250);
    glColor3f(0,0.8,0.5);
    text = "START GAME";
    DrawText(text.data(), text.size(), 260, 188);
    text = "QUIT";
    DrawText(text.data(), text.size(), 285, 135);
    glColor3f(0.70, 0.96, 0.96);
    text = "INST: YOU HAVE ONLY 3 LIFE CHANCE AND CONTROL THE GAME WITH THE LEFT RIGHT ARROW";
    DrawText(text.data(), text.size(), 20, 20);

    glFlush();

}


//MOUSE EVENT
int mouseX = 0, mouseY = 0;

void mouse_motion(int x, int y)
{
    glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
    mouseX = x;
    mouseY = y;
    switch(button)
    {
        case GLUT_LEFT_BUTTON:
            if(state==GLUT_DOWN)
            {

                    if(mouseX >=330 && mouseX <= 900)
                            if(mouseY >= 265 && mouseY <= 320)
                            {
                                glutDisplayFunc(Background);
                            }
                    else if(mouseX >=330 && mouseX <= 900)
                            if(mouseY >= 350 && mouseY <= 420)
                            {
                                exit(0);

                            }
            }
            default:
            break;
    }

}

//KEY EVENT

void SpecialInput (int key, int x, int y)
{

    switch (key)
    {
    case GLUT_KEY_LEFT :
        if(posx < -.8 )
        {
            posx =  -.9;
            glutPostRedisplay();
            break;

        }
        else
        {

            posx = posx - .1;
            glutPostRedisplay();
            break;
        }

    case GLUT_KEY_RIGHT :
               if(posx > .8)
        {
            posx =  .8;
            glutPostRedisplay();
            break;

        }
        else
        {
            posx = posx + .1;
            glutPostRedisplay();
            break;
        }


    }
}

//RUN
void display()
{
   Menu();

}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1200, 600);
	glutInitWindowPosition(50, 90);
	glutCreateWindow(" JUNGLE TARZAN ");

    glutDisplayFunc(display);
    glutSpecialFunc(SpecialInput);
    glutMouseFunc(mouse);
    glutPassiveMotionFunc(mouse_motion);

    glutMainLoop();

}

